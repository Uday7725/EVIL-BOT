karma_positive_group = 3
karma_negative_group = 4
