__mod_name__ = "◎Music"

__help__ = """
/video <i>query</i>: download video from youtube
/deezer <i>query</i>: download from deezer
/music <i>query</i>: download song from yt servers. (API BASED)
/lyrics <i>song name</i> : This plugin searches for song lyrics with song name.
/glyrics <i> song name </i> : This plugin searches for song lyrics with song name and artist.
"""
